   ____ _____ ___   _   _      _       ____            _    
  / ___|  ___|_ _| | | | | ___| |_ __ |  _ \  ___  ___| | __
 | |  _| |_   | |  | |_| |/ _ \ | '_ \| | | |/ _ \/ __| |/ /
 | |_| |  _|  | |  |  _  |  __/ | |_) | |_| |  __/\__ \   < 
  \____|_|   |___| |_| |_|\___|_| .__/|____/ \___||___/_|\_\
                                |_|                                            
					(powered by Kayako)
----------------------------------------------------------------------------------
GFI Software - https://www.gfi.com/helpdesk

Thanks for downloading GFI Helpdesk!
------------------------------------

First time install?
==================
Please ensure that your hosting environment is setup with the requirements needed to run GFI HelpDesk. 
These steps are very IMPORTANT for a successful install 
https://go.gfi.com/?pageid=GFIHelpDeskInstall

Updating?
==================
Make sure you read the specific instructions on our release notes for this version
You can find our release notes on our wiki:
https://upgrades.gfi.com

Installation Steps
==================
1) IMPORTANT: For a successfull installation please read the installation instructions https://go.gfi.com/?pageid=GFIHelpDeskInstall
2) Unpack the upload directory to your web server location
3) Make sure that your license key.php file is available
4) Go to the below and make sure all errors/warnings are addressed prior proceeding with he installation.

	[ http://<SUPPORT HOST/Path...>/checklist.php ] 
	or 
	[ http://localhost/checklist.php ] 


(Requires PHP 7.1+ or MySQL 5.6.31+ or MariaDB 10+)


Further help?
==================
You can contact our support team by going to https://support.gfi.com
You can also ask our excellent community for help at our forums: https://forums.gfi.com


Legal
==================
This software is governed by the EULA at https://www.gfi.com/pages/end-user-license-agreement

GFI is a registered trademark of GFI Software or its affiliates in the US and other countries. Kayako is a registered trademark of Kayako Singapore Pte. Ltd. or its affiliates in the US and other countries. Any other trademarks contained herein are the property of their respective owners.