<?php
/**
 * =======================================
 * ###################################
 * SWIFT Framework
 *
 * @package    SWIFT
 * @author    Kayako Singapore Pte. Ltd.
 * @copyright    Copyright (c) 2001-Kayako Singapore Pte. Ltd.h Ltd.
 * @license    http://www.kayako.com/license
 * @link        http://www.kayako.com
 * @filesource
 * ###################################
 * =======================================
 */

/**
 * KQL2 Tests
 *
 * @author Andriy Lesyuk
 */
class SWIFT_KQL2Test extends SWIFT_TestCase
{

    /**
     * Tests the GetPrecedenceGroups()
     *
     * @author Andriy Lesyuk
     */
    public function testGetPrecedenceGroups()
    {
        // TODO: Test GetPrecedenceGroups()!
        $this->assertTrue(true);
    }

}
