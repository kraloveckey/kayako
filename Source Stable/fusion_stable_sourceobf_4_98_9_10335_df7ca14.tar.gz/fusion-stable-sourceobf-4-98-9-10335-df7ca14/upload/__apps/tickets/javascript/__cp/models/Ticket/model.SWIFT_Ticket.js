SWIFT.Models.Tickets.Ticket = SWIFT.Library.Model.extend({

});