<?php 
print $this->t($this->data['res']);
?>
