<?php
/**
 * PHP LDAP CLASS FOR MANIPULATING ACTIVE DIRECTORY 
 * Version 4.0.4
 * 
 * PHP Version 5 or 7.x with SSL and LDAP support
 * 
 * http://adldap.sourceforge.net/
 * 
 * 
 * @category ToolsAndUtilities
 * @package adLDAP
 * @subpackage GroupCollection
 * @version 4.0.4
 * @link http://adldap.sourceforge.net/
 */

class adLDAPGroupCollection extends adLDAPCollection 
{
    
    public function __set($attribute, $value)
    {

    }
}
?>
