--------------------------------------------------------------------------------
| Name:			Import AD Groups for Basic Active Directory Authenticator for Kayako LoginShare v4
|
| Version:		v1.0.0
|
| Description:	Imports AD groups to user groups and/or staff teams
|
|
| Installation Level:	Easy
| Installation Time:	Couple of minutes
|
| Files To Edit (#):	0
--------------------------------------------------------------------------------
| Notes:
|		Requirements:
|			Basic Active Directory Authenticator for Kayako LoginShare v4
|
|	You must have your username and password, and be in testing mode in the
|	config.php for this to work.
|
--------------------------------------------------------------------------------